package com.example.leonardo.trabalhojean;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pedro on 18/04/2016.
 */
public class InfoDAO extends SQLiteOpenHelper {

    private static final int VERSAO = 2;
    private static final String TABELA = "Aluno";
    private static final String[] COLS = {"id", "nome", "telefone"};

    public InfoDAO(Context context) {
        super(context, TABELA, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE " + TABELA + " ");
        sb.append("(id INTEGER PRIMARY KEY, ");
        sb.append(" nome TEXT UNIQUE NOT NULL, ");
        sb.append(" telefone TEXT, ");

        db.execSQL(sb.toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        StringBuilder sb = new StringBuilder();
        sb.append("DROP TABLE IF EXISTS " + TABELA);
        db.execSQL(sb.toString());
        onCreate(db);

    }

    public void inserir(Info info) {
        ContentValues values = new ContentValues();
        values.put("nome", info.getNome());
        values.put("telefone", info.getTelefone());


        getWritableDatabase().insert(TABELA, null, values);
    }

    public List<Info> getLista(){
        List<Info> infos = new ArrayList<Info>();

        Cursor c = getWritableDatabase().query(TABELA,COLS, null, null, null, null, null);

        while(c.moveToNext()){
            Info info = new Info();
            info.setId(c.getLong(0));
            info.setNome(c.getString(1));
            info.setTelefone(c.getString(2));

            infos.add(info);
        }
        c.close();

        return infos;
    }
}

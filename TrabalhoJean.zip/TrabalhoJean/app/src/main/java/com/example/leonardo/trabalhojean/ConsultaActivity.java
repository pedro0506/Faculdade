package com.example.leonardo.trabalhojean;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Leonardo on 18/04/2016.
 */
public class ConsultaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista);
    }
}

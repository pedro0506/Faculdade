package com.example.leonardo.trabalhojean;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

/**
 * Created by Leonardo on 18/04/2016.
 */
public class Formulario extends Activity {

    private Info info = new Info();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);

        Button botao = (Button) findViewById(R.id.botao);
        botao.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText nome = (EditText) findViewById(R.id.nome);
                EditText telefone = (EditText) findViewById(R.id.telefone);


                info.setNome(nome.getEditableText().toString());
                info.setTelefone(telefone.getEditableText().toString());




                InfoDAO dao = new InfoDAO(Formulario.this);
                dao.inserir(info);
                dao.close();

                finish();
            }
        });
    }
}
